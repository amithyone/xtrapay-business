<?php $__env->startSection('content'); ?>
<form class="login100-form validate-form" method="POST" action="<?php echo e(route('register')); ?>">
    <?php echo csrf_field(); ?>
    
    <span class="login100-form-title p-b-49">
        Create Account
    </span>

    <?php if($errors->any()): ?>
        <div class="bg-red-500/10 border border-red-500/20 text-red-500 rounded-lg p-4 mb-6">
            <ul class="list-disc list-inside">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="wrap-input100 validate-input m-b-23" data-validate="Name is required">
        <span class="label-input100">Full Name</span>
        <input class="input100" type="text" name="name" value="<?php echo e(old('name')); ?>" required autofocus placeholder="Type your full name">
        <span class="focus-input100" data-symbol="&#xf206;">
            <i class="fas fa-user"></i>
        </span>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-500 text-sm mt-2 flex items-center">
                <i class="fas fa-exclamation-circle mr-1"></i>
                <?php echo e($message); ?>

            </p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="wrap-input100 validate-input m-b-23" data-validate="Email is required">
        <span class="label-input100">Email Address</span>
        <input class="input100" type="email" name="email" value="<?php echo e(old('email')); ?>" required placeholder="Type your email">
        <span class="focus-input100" data-symbol="&#xf206;">
            <i class="fas fa-envelope"></i>
        </span>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-500 text-sm mt-2 flex items-center">
                <i class="fas fa-exclamation-circle mr-1"></i>
                <?php echo e($message); ?>

            </p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="wrap-input100 validate-input m-b-23" data-validate="Password is required">
        <span class="label-input100">Password</span>
        <input class="input100" type="password" name="password" required placeholder="Type your password">
        <span class="focus-input100" data-symbol="&#xf190;">
            <i class="fas fa-lock"></i>
        </span>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-500 text-sm mt-2 flex items-center">
                <i class="fas fa-exclamation-circle mr-1"></i>
                <?php echo e($message); ?>

            </p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="wrap-input100 validate-input" data-validate="Password confirmation is required">
        <span class="label-input100">Confirm Password</span>
        <input class="input100" type="password" name="password_confirmation" required placeholder="Confirm your password">
        <span class="focus-input100" data-symbol="&#xf190;">
            <i class="fas fa-check-circle"></i>
        </span>
    </div>

    <div class="container-login100-form-btn">
        <div class="wrap-login100-form-btn">
            <div class="login100-form-bgbtn"></div>
            <button class="login100-form-btn" type="submit">
                Create Account
            </button>
        </div>
    </div>

    <div class="txt1 text-center p-t-54 p-b-20">
        <span>
            Already have an account?
        </span>
    </div>

    <div class="flex-col-c p-t-155">
        <span class="txt1 p-b-17">
            Sign in to your account
        </span>

        <a href="<?php echo e(route('login')); ?>" class="txt2">
            Sign In
        </a>
    </div>

    <div class="txt1 text-center p-t-20">
        <span>
            Learn more about our service
        </span>
    </div>

    <div class="flex-col-c p-t-20">
        <a href="<?php echo e(route('information')); ?>" class="txt2">
            Service Information
        </a>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/amiithyone/Documents/Xtrabusiness/resources/views/auth/register.blade.php ENDPATH**/ ?>