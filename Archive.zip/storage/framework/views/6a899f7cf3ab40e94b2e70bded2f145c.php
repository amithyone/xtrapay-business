<?php $__env->startSection('content'); ?>
<form class="login100-form validate-form" method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo csrf_field(); ?>
    
    <span class="login100-form-title p-b-49">
        Welcome Back
    </span>

    <?php if(session('status')): ?>
        <div class="alert-box mb-4 p-4 rounded-lg bg-green-500 text-white font-semibold shadow flex justify-between items-center">
            <span><?php echo e(session('status')); ?></span>
            <button onclick="dismissAlert(this.closest('.alert-box'))" class="text-white hover:text-gray-200 ml-4 text-2xl leading-none">&times;</button>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="bg-red-500/10 border border-red-500/20 text-red-500 rounded-lg p-4 mb-6">
            <ul class="list-disc list-inside">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="wrap-input100 validate-input m-b-23" data-validate="Username is required">
        <span class="label-input100">Username or Email</span>
        <input class="input100" type="text" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="Type your username or email">
        <span class="focus-input100" data-symbol="&#xf206;">
            <i class="fas fa-user"></i>
        </span>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-500 text-sm mt-2 flex items-center">
                <i class="fas fa-exclamation-circle mr-1"></i>
                <?php echo e($message); ?>

            </p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="wrap-input100 validate-input" data-validate="Password is required">
        <span class="label-input100">Password</span>
        <input class="input100" type="password" name="password" required placeholder="Type your password">
        <span class="focus-input100" data-symbol="&#xf190;">
            <i class="fas fa-lock"></i>
        </span>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-500 text-sm mt-2 flex items-center">
                <i class="fas fa-exclamation-circle mr-1"></i>
                <?php echo e($message); ?>

            </p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="text-right p-t-8 p-b-31">
        <a href="#" class="txt2">
            Forgot password?
        </a>
    </div>

    <div class="container-login100-form-btn">
        <div class="wrap-login100-form-btn">
            <div class="login100-form-bgbtn"></div>
            <button class="login100-form-btn" type="submit">
                Sign In
            </button>
        </div>
    </div>

    <div class="txt1 text-center p-t-54 p-b-20">
        <span>
            New to Xtrabusiness?
        </span>
    </div>

    <div class="flex-col-c p-t-155">
        <span class="txt1 p-b-17">
            Don't have an account?
        </span>

        <a href="<?php echo e(route('register')); ?>" class="txt2">
            Sign Up
        </a>
    </div>
</form>

<script>
function dismissAlert(element) {
    if (element) {
        element.style.opacity = '0';
        setTimeout(() => {
            element.remove();
        }, 300);
    }
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/amiithyone/Documents/Xtrabusiness/resources/views/auth/login.blade.php ENDPATH**/ ?>