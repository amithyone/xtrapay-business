<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\SiteController;
use App\Http\Controllers\TransactionController;
use App\Http\Controllers\WithdrawalController;
use App\Http\Controllers\BusinessProfileController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Auth\PasswordResetLinkController;
use App\Http\Controllers\Auth\NewPasswordController;
use App\Http\Controllers\Auth\EmailVerificationPromptController;
use App\Http\Controllers\Auth\VerifyEmailController;
use App\Http\Controllers\Auth\EmailVerificationNotificationController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PasswordController;
use App\Http\Controllers\BeneficiaryController;
use App\Http\Controllers\TicketController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\StatisticsController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

// Authentication Routes
Route::middleware('guest')->group(function () {
    Route::get('login', [AuthenticatedSessionController::class, 'create'])
        ->name('login');
    Route::post('login', [AuthenticatedSessionController::class, 'store']);

    // Registration Routes
    Route::get('register', [RegisterController::class, 'showRegistrationForm'])->name('register');
    Route::post('register', [RegisterController::class, 'register']);

    // Password Reset Routes
    Route::get('forgot-password', [PasswordResetLinkController::class, 'create'])
        ->name('password.request');
    Route::post('forgot-password', [PasswordResetLinkController::class, 'store'])
        ->name('password.email');
    Route::get('reset-password/{token}', [NewPasswordController::class, 'create'])
        ->name('password.reset');
    Route::post('reset-password', [NewPasswordController::class, 'store'])
        ->name('password.store');
});

// Email Verification Routes
Route::middleware('auth')->group(function () {
    Route::get('verify-email', [EmailVerificationPromptController::class, '__invoke'])
        ->name('verification.notice');
    Route::get('verify-email/{id}/{hash}', [VerifyEmailController::class, '__invoke'])
        ->middleware(['signed', 'throttle:6,1'])
        ->name('verification.verify');
    Route::post('email/verification-notification', [EmailVerificationNotificationController::class, 'store'])
        ->middleware('throttle:6,1')
        ->name('verification.send');
});

Route::middleware('auth')->group(function () {
    Route::post('logout', [AuthenticatedSessionController::class, 'destroy'])
        ->name('logout');
    
    // Email verification routes (no verification required)
    Route::get('verify-email', [EmailVerificationPromptController::class, '__invoke'])
        ->name('verification.notice');
    Route::get('verify-email/{id}/{hash}', [VerifyEmailController::class, '__invoke'])
        ->middleware(['signed', 'throttle:6,1'])
        ->name('verification.verify');
    Route::post('email/verification-notification', [EmailVerificationNotificationController::class, 'store'])
        ->middleware('throttle:6,1')
        ->name('verification.send');
});

// Routes that require email verification
Route::middleware(['auth', 'verified'])->group(function () {
    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Business Profile Routes
    Route::resource('business-profile', BusinessProfileController::class);

    // Site Routes
    Route::resource('sites', SiteController::class);
    Route::post('/sites/{site}/activate', [SiteController::class, 'activate'])->name('sites.activate');
    Route::post('/sites/{site}/deactivate', [SiteController::class, 'deactivate'])->name('sites.deactivate');
    Route::delete('/sites/{site}', [SiteController::class, 'destroy'])->name('sites.destroy');

    // Transaction Routes
    Route::resource('transactions', TransactionController::class);

    // Statistics Routes
    Route::get('/statistics', [StatisticsController::class, 'index'])->name('statistics.index');
    Route::get('/statistics/chart-data', [StatisticsController::class, 'getChartDataAjax'])->name('statistics.chart-data');

    // Withdrawal Routes
    Route::get('/withdrawals', [WithdrawalController::class, 'index'])->name('withdrawals.index');
    Route::post('/withdrawals', [WithdrawalController::class, 'store'])->name('withdrawals.store');
    Route::get('/withdrawal-dashboard', [WithdrawalController::class, 'withdrawalDashboard'])->name('withdrawal.dashboard');

    // Profile Routes
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    
    // Password Management
    Route::patch('/profile/password', [ProfileController::class, 'updatePassword'])->name('profile.password.update');
    
    // PIN Management
    Route::post('/profile/pin/create', [ProfileController::class, 'createPin'])->name('profile.pin.create');
    Route::patch('/profile/pin/update', [ProfileController::class, 'updatePin'])->name('profile.pin.update');
    
    // Legacy Password Route (for compatibility)
    Route::put('/password', [PasswordController::class, 'update'])->name('password.update');

    // Beneficiary Routes
    Route::get('/beneficiaries', [BeneficiaryController::class, 'index'])->name('beneficiaries.index');
    Route::post('/beneficiaries', [BeneficiaryController::class, 'store'])->name('beneficiaries.store');
    Route::put('/beneficiaries/{beneficiary}', [BeneficiaryController::class, 'update'])->name('beneficiaries.update');
    Route::delete('/beneficiaries/{beneficiary}', [BeneficiaryController::class, 'destroy'])->name('beneficiaries.destroy');

    // Ticket Routes
    Route::resource('tickets', \App\Http\Controllers\TicketController::class);

    // Notification Routes
    Route::get('/notifications', [NotificationController::class, 'index'])->name('notifications.index');
    Route::post('/notifications/settings', [NotificationController::class, 'saveSettings'])->name('notifications.settings');

    // API Routes
    Route::post('/api/generate-token', [DashboardController::class, 'generateApiToken'])->name('api.generate-token');
    Route::get('/api/v1/sites', [DashboardController::class, 'getSites'])->name('api.sites');
    Route::get('/api/v1/transactions', [DashboardController::class, 'getTransactions'])->name('api.transactions');
    Route::get('/api/v1/revenue', [DashboardController::class, 'getRevenue'])->name('api.revenue');
    Route::post('/api/v1/webhook/transaction', [DashboardController::class, 'webhookTransaction'])->name('api.webhook.transaction');
    
    // Dashboard Transactions Pagination
    Route::get('/dashboard/transactions', [DashboardController::class, 'getDashboardTransactions'])->name('dashboard.transactions');
});

// Admin Routes (separate from verified routes)
Route::middleware(['auth', 'admin'])->group(function () {
    // Site Management
    Route::post('/admin/sites', [AdminController::class, 'storeSite'])->name('admin.sites.store');
    Route::get('/admin/sites/{site}', [AdminController::class, 'viewSite'])->name('admin.sites.view');
    Route::put('/admin/sites/{site}', [AdminController::class, 'updateSite'])->name('admin.sites.update');
    
    // Transaction Management
    Route::post('/admin/transactions/{transaction}/approve', [AdminController::class, 'approveTransaction'])->name('admin.transactions.approve');
    Route::post('/admin/transactions/{transaction}/reject', [AdminController::class, 'rejectTransaction'])->name('admin.transactions.reject');
    
    // Withdrawal Management
    Route::post('/admin/withdrawals/{transfer}/approve', [AdminController::class, 'approveWithdrawal'])->name('admin.withdrawals.approve');
    Route::post('/admin/withdrawals/{transfer}/reject', [AdminController::class, 'rejectWithdrawal'])->name('admin.withdrawals.reject');
    
    // Logs
    Route::get('/admin/logs/{transaction}', [AdminController::class, 'viewLogDetails'])->name('admin.logs.view');
});



// Information page
Route::get('/information', function () {
    return view('information');
})->name('information');

// Redirect root to information page
Route::get('/', function () {
    return redirect()->route('information');
});

// PWA Routes
Route::get('/manifest.json', function () {
    return response()->file(public_path('manifest.json'), [
        'Content-Type' => 'application/manifest+json'
    ]);
});

Route::get('/sw.js', function () {
    return response()->file(public_path('sw.js'), [
        'Content-Type' => 'application/javascript'
    ]);
});

Route::get('/admin', [AdminController::class, 'index'])->name('admin.index');
Route::get('/manager', [AdminController::class, 'showCodeInput'])->name('admin.code.input');
Route::post('/manager/verify-code', [AdminController::class, 'verifyCode'])->name('admin.code.verify');
Route::get('/manager/second-code', [AdminController::class, 'showSecondCode'])->name('admin.second_code');
Route::post('/manager/verify-second-code', [AdminController::class, 'verifySecondCode'])->name('admin.verify_second_code');
Route::get('/manager/admin-login', [AdminController::class, 'showAdminLogin'])->name('admin.admin_login');
Route::post('/manager/admin-login', [AdminController::class, 'login'])->name('admin.login');
Route::get('/manager/dashboard', [AdminController::class, 'index'])->name('admin.index');



Route::get('/test-telegram', function () {
    $user = auth()->user();
    $chatId = $user->telegram_chat_id; // Make sure this is set!
    $message = "🚀 Test notification from Xtrabusiness!";
    return app(NotificationController::class)->sendTelegramNotification($chatId, $message);
});

Route::get('/test-business-telegram', [NotificationController::class, 'testBusinessTelegram'])->middleware('auth');

// Debug route to check current Telegram settings
Route::get('/debug-telegram-settings', function () {
    $user = auth()->user();
    $business = $user->businessProfile;
    
    return response()->json([
        'user_id' => $user->id,
        'business_profile_id' => $business ? $business->id : null,
        'telegram_bot_token' => $business ? $business->telegram_bot_token : null,
        'telegram_chat_id' => $business ? $business->telegram_chat_id : null,
        'business_exists' => $business ? true : false
    ]);
})->middleware('auth');

// Test route to simulate form submission
Route::post('/test-telegram-save', function (Request $request) {
    $user = auth()->user();
    $business = $user->businessProfile;
    
    if (!$business) {
        return response()->json(['error' => 'No business profile found'], 404);
    }
    
    $data = $request->only('telegram_bot_token', 'telegram_chat_id');
    $updated = $business->update($data);
    
    return response()->json([
        'success' => $updated,
        'received_data' => $data,
        'business_id' => $business->id,
        'updated_values' => [
            'telegram_bot_token' => $business->telegram_bot_token,
            'telegram_chat_id' => $business->telegram_chat_id
        ]
    ]);
})->middleware('auth');

// Test route to get chat ID and test notifications
Route::get('/test-telegram-chat', function () {
    $user = auth()->user();
    $business = $user->businessProfile;
    
    if (!$business || !$business->telegram_bot_token) {
        return response()->json(['error' => 'No Telegram bot token configured'], 404);
    }
    
    // Test bot info
    $botInfo = Http::get("https://api.telegram.org/bot{$business->telegram_bot_token}/getMe")->json();
    
    // Test sending to current chat ID
    $testResult = null;
    if ($business->telegram_chat_id) {
        $testResult = Http::post("https://api.telegram.org/bot{$business->telegram_bot_token}/sendMessage", [
            'chat_id' => $business->telegram_chat_id,
            'text' => '🧪 Test notification from Xtrabusiness! If you see this, your chat ID is correct.',
        ])->json();
    }
    
    return response()->json([
        'bot_info' => $botInfo,
        'current_chat_id' => $business->telegram_chat_id,
        'test_result' => $testResult,
        'instructions' => [
            '1. Make sure you have started a chat with @xtarbuinessbot',
            '2. Send any message to the bot',
            '3. Try the test again',
            '4. If still failing, try getting your chat ID from @userinfobot'
        ]
    ]);
})->middleware('auth');

